Yii2 Gentelella Change Log
==========================

1.4.0 Under development
-----------------------

1.3.1 Nov 12, 2017
------------------

- Enh #26: Removed a demo code from `ThemeAsset` (fps01)

1.3.0 Aug 19, 2017
------------------

- Enh #25: Implemented another algorithm of sidebar state keeping (mohdqasim98)
- Enh #23: Added an ability to add custom buttons in Panel widget (SamMousa)
- Enh #20: Added an ability to make an active menu item via `active` attribute (fps01)
- Enh #22: Created Accordion widget (fps01)
- Fix #17: Fixed source paths for bower (MKiselev)
- Fix #15: Fixed an error "Jquery Error progressbar is not a function" (fps01)
- Fix #13: Make FlashAlert widget array compatible (al.gushchin)

1.2.0 August 1, 2016
--------------------

- Fix #9: Temporary fix for fxp 1.2.0 (fps01)
- Enh #7: Add a an ability to add custom items to dropdown list of `yiister\gentelella\widgets\Panel` (fps01)
- New #8: Added a `yiister\gentelella\widgets\Timeline` widget (fps01)
- New #5: Added an ability to keep a sidebar state (fps01)
- Fix #6: using a PHP 5.4 instead of 5.5

1.1.0 June 26, 2016
-------------------

- New #3: Added a `yiister\gentelella\widgets\StatsTile` widget (fps01)
- New #2: Added a `yiister\gentelella\widgets\grid\GridView` widget (fps01)
- New #4: Added a `yiister\gentelella\widgets\FlashAlert` widget (fps01)

1.0.0 June 04, 2016
-------------------

- Initial release
