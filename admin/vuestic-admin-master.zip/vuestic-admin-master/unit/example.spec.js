describe('App', () => {
  // Mock test is required so that jest does not complain we have no tests on job.
  it('runs a mock test', () => {
    expect(true).toBe(true)
  })
})
