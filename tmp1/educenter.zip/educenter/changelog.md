## Version 1.0.0 (4 aug 2019)
- Initial template
- Bootstrap version 4.1.1

## Version 1.1.0 (29 apr 2020)
- Fixed navigation on mobile menu
- Fix responsive issues