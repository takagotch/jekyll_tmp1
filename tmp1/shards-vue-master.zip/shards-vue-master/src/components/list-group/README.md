# List Groups

List groups allow you to display series of content.

## Basic Example

You can create list groups using the `<d-list-group>` component with the `<d-list-group-item>` sub-component.

:::demo
```html

<d-list-group>
  <d-list-group-item>Cras justo odio</d-list-group-item>
  <d-list-group-item>Dapibus ac facilisis in</d-list-group-item>
  <d-list-group-item>Morbi leo risus</d-list-group-item>
  <d-list-group-item>Porta ac consectetur ac</d-list-group-item>
  <d-list-group-item>Vestibulum at eros</d-list-group-item>
</d-list-group>


<!-- list-group-1.vue -->
```
:::
